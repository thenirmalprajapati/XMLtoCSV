﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Xsl;

namespace XMLtoJSON
{
    class Program
    {
        static void Main(string[] args)
        {
            string baseName = @"C:\Users\Nirmal\Downloads\XMLtoJSON (2)\XMLtoJSON\XMLtoJSON";
            XslTransform myXslTransfom = new XslTransform();

            myXslTransfom.Load(baseName + "\\Customer.xslt");
            myXslTransfom.Transform(baseName + "\\Customer.xml", baseName + "\\OutputCustomer.xml");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\CustomerNotes.xslt");
            myXslTransfom.Transform(baseName + "\\Customer.xml", baseName + "\\OutputCustomerNotes.xml");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\CustomerReference.xslt");
            myXslTransfom.Transform(baseName + "\\Customer.xml", baseName + "\\OutputCustomerReference.xml");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\CustomerCommunication.xslt");
            myXslTransfom.Transform(baseName + "\\Customer.xml", baseName + "\\OutputCustomerCommunication.xml");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\CSVCustomer.xslt");
            myXslTransfom.Transform(baseName + "\\OutputCustomer.xml", baseName + "\\OutputCustomerCSV.csv");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\CSVCustomerNotes.xslt");
            myXslTransfom.Transform(baseName + "\\OutputCustomerNotes.xml", baseName + "\\OutputCustomerNotesCSV.csv");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\CSVCustomerReference.xslt");
            myXslTransfom.Transform(baseName + "\\OutputCustomerReference.xml", baseName + "\\OutputCustomerReferenceCSV.csv");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\CSVCustomerCommunication.xslt");
            myXslTransfom.Transform(baseName + "\\OutputCustomerCommunication.xml", baseName + "\\OutputCustomerCommunicationCSV.csv");


            //SalesOrder
            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\SalesOrder.xslt");
            myXslTransfom.Transform(baseName + "\\SalesOrder.xml", baseName + "\\OutputSalesOrder.xml");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\SalesOrderReference.xslt");
            myXslTransfom.Transform(baseName + "\\SalesOrder.xml", baseName + "\\OutputSalesOrderReference.xml");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\SalesOrderLine.xslt");
            myXslTransfom.Transform(baseName + "\\SalesOrder.xml", baseName + "\\OutputSalesOrderLine.xml");


            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\SalesOrderData.xslt");
            myXslTransfom.Transform(baseName + "\\OutputSalesOrder.xml", baseName + "\\OutputSalesOrderData.csv");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\SalesOrderReferenceData.xslt");
            myXslTransfom.Transform(baseName + "\\OutputSalesOrderReference.xml", baseName + "\\OutputSalesOrderReferenceData.csv");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\SalesOrderLineData.xslt");
            myXslTransfom.Transform(baseName + "\\OutputSalesOrderLine.xml", baseName + "\\OutputSalesOrderLineData.csv");

            //Invoice
            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\Invoice.xslt");
            myXslTransfom.Transform(baseName + "\\Invoice.xml", baseName + "\\OutputInvoice.xml");


        }
    }
}
